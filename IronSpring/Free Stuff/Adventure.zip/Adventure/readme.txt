Adventure
---------

This is the PL/I version of the original Adventure game by 
William Crowther and Donald Woods.  A description of the
game and the various versions can be found here:
    http://rickadams.org/adventure/e_downloads.html
    
This is the Adventure 350-point version.  The PL/I port is 
attributed (as far as I know) only to "Some nice person from IBM". 
The source and data was downloaded from the "CBT Tape",
file 269:
    http://www.cbttape.org/cbtdowns.htm  
    
Very little was done to get it to compile with Iron Spring PL/I -
primarily replacing iterative specifications in input/output data lists
[GET LIST( (a(i) DO i=1 TO 5) );], which are not yet supported by
this compiler.  The assembler routines in the original were replaced
by PL/I: random number generation, timer access, and interactive I/O.
The original code was retained as comments, and the changes I have made
are indicated by the comment /*PRF*/.

I have done a small amount of testing, but have not completed the game.
If anyone who is familiar with the game finds any problems, please
contact me at the address below.

The executable "advent" ("advent.exe" for OS/2) is standalone.  No other 
packages are required to run it.  The data file "advent.dat" is assumed to 
reside in your current working directory.  If you want to compile advent
from source you will need the Iron Spring PL/I compiler ("plic")
in /usr/bin, and the library ("libprf.a") in /usr/local/lib [for Linux].
These can be downloaded from Iron Spring Software at:
  http://www.iron-spring.com
Version 0.9.4c or later is required.

Enjoy! 

Contents:
--------
  advent     - Linux executable
  advent.exe - OS/2 executable
  advent.dat - data file
  makefile   - required to recompile
  readme.txt - this file.
  
Contact:
-------
Iron Spring Software
Peter@Iron-Spring.com


April 9, 2014
